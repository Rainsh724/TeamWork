#ifndef PVPSTART1_H
#define PVPSTART1_H

#include <QDialog>
#include <QtMultimedia>
#include <QAudioOutput>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QDebug>
#include <QFile>
#include <QUrl>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QListWidget>
#include <QListWidgetItem>


namespace Ui {
class pvpStart1;
}

class pvpStart1 : public QDialog
{
    Q_OBJECT

public:
    explicit pvpStart1(QWidget *parent = nullptr);
    ~pvpStart1();

private slots:
    void on_start_clicked();
    void fetchQuestions();
    void handleResponse(QNetworkReply *reply);
    void on_back_clicked();
    void on_Home_clicked();

private:
    Ui::pvpStart1 *ui;
    QMediaPlayer *M_Player;
    QAudioOutput* audioOutput;
};

#endif // PVPSTART1_H
