#include "survgame.h"
#include "ui_survgame.h"
#include "mainwindow.h"
#include "survstart.h"
#include "survsub.h"
survSub *ssub;
survStart *surS2;
MainWindow *mw5;


survgame::survgame(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::survgame)
{
    ui->setupUi(this);

    QFile file("sub.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return;
    QTextStream in(&file);
        int num;
        in >> num;

    survgame::prinQuestions();
    ui->countdown->setText("0:30");
    timer = new QTimer();
    timer ->remainingTime();
    timer->start(1000);
     connect(timer, SIGNAL(timeout()), this, SLOT(updateCountdown()));

}

survgame::~survgame()
{
    delete ui;
}


void survgame::on_Home_clicked()
{
    timer ->stop();
    M_Player = new QMediaPlayer();
    audioOutput = new QAudioOutput();
    M_Player -> setAudioOutput(audioOutput);
    M_Player -> setSource(QUrl("qrc:/sound/sounds/ui-digital-button-click-gfx-sounds-1-00-00.mp3"));
     audioOutput->setVolume(0.5);
    M_Player -> play();
    hide();
    mw5 = new MainWindow(this);
    mw5 -> show();
}

void survgame::prinQuestions()
{
    QString question;
    QString correct;
    QString incorrect1;
    QString incorrect2;
    QString incorrect3;
    QFile Readquestions("questios.txt");
    if (Readquestions.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        QTextStream readq(&Readquestions);
        readq>>question;
        readq>>incorrect1;
        readq>>incorrect2;
        readq>>incorrect3;
        readq>>correct;



    //print data
    ui->label->setText(question);
    }

}

void survgame::updateCountdown()
{
    static int remainingSeconds = 30;
        remainingSeconds--;

        int minutes = remainingSeconds / 30;
        int seconds = remainingSeconds % 30;
        ui->countdown->setText(QString("%1:%2").arg(minutes).arg(seconds, 2, 10, QChar('0')));

    QMessageBox msgBox;
    QMessageBox::StandardButton reply;
        if (remainingSeconds == 0)
            {
            timer->stop();
            M_Player = new QMediaPlayer();
            audioOutput = new QAudioOutput();
            M_Player -> setAudioOutput(audioOutput);
            M_Player -> setSource(QUrl("qrc:/sound/sounds/Download_Time_out_sound_effect_Royalty_Free_Music_&_Sound_Effects.mp4"));
             audioOutput->setVolume(0.5);
            M_Player -> play();
            msgBox.setStyleSheet("background : rgb(185, 154, 247)");
            msgBox.setText("Do You Want To Know The Correct Answer?");
            msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
           int reply = msgBox.exec();
            if (reply == QMessageBox::Yes) {
                auto msgBox2 = new QMessageBox();
                msgBox2->setMinimumSize(300, 300);
                msgBox2->setStyleSheet("QMessageBox{background: rgb(185, 154, 247)}"
                                       "QPushButton{ background : rgb(185, 154, 247)}");
                msgBox2->setText("Coming soon!");
                msgBox2->exec();
            }
            hide();
            surS2 = new survStart(this);
            surS2 -> show();
            }
}

void survgame::on_N1_clicked()
{
    timer->stop();

    M_Player = new QMediaPlayer();
    audioOutput = new QAudioOutput();
    M_Player -> setAudioOutput(audioOutput);
    M_Player -> setSource(QUrl("qrc:/sound/sounds/Download_Time_out_sound_effect_Royalty_Free_Music_&_Sound_Effects.mp4"));
    audioOutput->setVolume(0.5);
    M_Player -> play();

    //-----------------------------------
    QString username1;
    QString pass1;
    int score1;
    int round;
    int newround;

    QFile Play("Players.txt");
    if (Play.open(QIODevice::ReadWrite | QIODevice::Text)){

        QTextStream data(&Play);
        data>>username1;
        data>>pass1;
        data>>score1;
        data >> round;
        newround=round+1;
        //  score1++;


        QFile Play1("Players.txt");
        if (Play1.open(QIODevice::WriteOnly | QIODevice::Text)){

            QTextStream data(&Play1);
            data << username1;
            data<<"\n";
            data << pass1;
            data<<"\n";
            data<<score1;
            data<<"\n";
            data <<newround<<"\n\n";

            if(newround%5==0)
            {

                QMessageBox msgBox;
                //    QMessageBox::StandardButton reply;
                msgBox.setStyleSheet("background : rgb(185, 154, 247)");
                msgBox.setText("Do You Want To Know The Correct Answer?");
                msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
                int reply1 = msgBox.exec();
                if (reply1 == QMessageBox::Yes) {
                    auto msgBox2 = new QMessageBox();
                    msgBox2->setMinimumSize(300, 300);
                    msgBox2->setStyleSheet("QMessageBox{background: rgb(185, 154, 247)}"
                                           "QPushButton{ background : rgb(185, 154, 247)}");
                    msgBox2->setText("Coming soon!");
                    msgBox2->exec();
                }

                QFile Play1("GamerData.txt");
                if (Play1.open(QIODevice::WriteOnly | QIODevice::Text)){

                    QTextStream data(&Play1);
                    data << username1;
                    data<<"\n";
                    data << pass1;
                    data<<"\n";
                    data<<score1;
                    data<<"\n\n";

                    QMessageBox msgBox;
                    msgBox.setText("You can check your score in Profile part!");
                    msgBox.exec();

                    hide();
                    ssub = new survSub(this);
                    ssub -> show();

                }
            }
        }
    }

    //-------------------------------

    if(newround%5!=0){

        QMessageBox msgBox;
        //    QMessageBox::StandardButton reply;
        msgBox.setStyleSheet("background : rgb(185, 154, 247)");
        msgBox.setText("Do You Want To Know The Correct Answer?");
        msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
        int reply1 = msgBox.exec();
        if (reply1 == QMessageBox::Yes) {
            auto msgBox2 = new QMessageBox();
            msgBox2->setMinimumSize(300, 300);
            msgBox2->setStyleSheet("QMessageBox{background: rgb(185, 154, 247)}"
                                   "QPushButton{ background : rgb(185, 154, 247)}");
            msgBox2->setText("Coming soon!");
            msgBox2->exec();
        }
        hide();
        surS2 = new survStart(this);
        surS2 -> show();
    }
    timer->stop();



}


void survgame::on_N2_clicked()
{
    timer->stop();
    timer->stop();

    M_Player = new QMediaPlayer();
    audioOutput = new QAudioOutput();
    M_Player -> setAudioOutput(audioOutput);
    M_Player -> setSource(QUrl("qrc:/sound/sounds/Download_Time_out_sound_effect_Royalty_Free_Music_&_Sound_Effects.mp4"));
    audioOutput->setVolume(0.5);
    M_Player -> play();

    //-----------------------------------
    QString username1;
    QString pass1;
    int score1;
    int round;
    int newround;

    QFile Play("Players.txt");
    if (Play.open(QIODevice::ReadWrite | QIODevice::Text)){

        QTextStream data(&Play);
        data>>username1;
        data>>pass1;
        data>>score1;
        data >> round;
        newround=round+1;
        //  score1++;


        QFile Play1("Players.txt");
        if (Play1.open(QIODevice::WriteOnly | QIODevice::Text)){

            QTextStream data(&Play1);
            data << username1;
            data<<"\n";
            data << pass1;
            data<<"\n";
            data<<score1;
            data<<"\n";
            data <<newround<<"\n\n";

            if(newround%5==0)
            {

                QMessageBox msgBox;
                //    QMessageBox::StandardButton reply;
                msgBox.setStyleSheet("background : rgb(185, 154, 247)");
                msgBox.setText("Do You Want To Know The Correct Answer?");
                msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
                int reply1 = msgBox.exec();
                if (reply1 == QMessageBox::Yes) {
                    auto msgBox2 = new QMessageBox();
                    msgBox2->setMinimumSize(300, 300);
                    msgBox2->setStyleSheet("QMessageBox{background: rgb(185, 154, 247)}"
                                           "QPushButton{ background : rgb(185, 154, 247)}");
                    msgBox2->setText("Coming soon!");
                    msgBox2->exec();
                }

                QFile Play1("GamerData.txt");
                if (Play1.open(QIODevice::WriteOnly | QIODevice::Text)){

                    QTextStream data(&Play1);
                    data << username1;
                    data<<"\n";
                    data << pass1;
                    data<<"\n";
                    data<<score1;
                    data<<"\n\n";

                    QMessageBox msgBox;
                    msgBox.setText("You can check your score in Profile part!");
                    msgBox.exec();

                    hide();
                    ssub = new survSub(this);
                    ssub -> show();

                }
            }
        }
    }

    //-------------------------------

    if(newround%5!=0){

        QMessageBox msgBox;
        //    QMessageBox::StandardButton reply;
        msgBox.setStyleSheet("background : rgb(185, 154, 247)");
        msgBox.setText("Do You Want To Know The Correct Answer?");
        msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
        int reply1 = msgBox.exec();
        if (reply1 == QMessageBox::Yes) {
            auto msgBox2 = new QMessageBox();
            msgBox2->setMinimumSize(300, 300);
            msgBox2->setStyleSheet("QMessageBox{background: rgb(185, 154, 247)}"
                                   "QPushButton{ background : rgb(185, 154, 247)}");
            msgBox2->setText("Coming soon!");
            msgBox2->exec();
        }
        hide();
        surS2 = new survStart(this);
        surS2 -> show();
    }



}

void survgame::on_N3_clicked()
{
    timer->stop();
    timer->stop();

    M_Player = new QMediaPlayer();
    audioOutput = new QAudioOutput();
    M_Player -> setAudioOutput(audioOutput);
    M_Player -> setSource(QUrl("qrc:/sound/sounds/Download_Time_out_sound_effect_Royalty_Free_Music_&_Sound_Effects.mp4"));
    audioOutput->setVolume(0.5);
    M_Player -> play();

    //-----------------------------------
    QString username1;
    QString pass1;
    int score1;
    int round;
    int newround;

    QFile Play("Players.txt");
    if (Play.open(QIODevice::ReadWrite | QIODevice::Text)){

        QTextStream data(&Play);
        data>>username1;
        data>>pass1;
        data>>score1;
        data >> round;
        newround=round+1;
        //  score1++;


        QFile Play1("Players.txt");
        if (Play1.open(QIODevice::WriteOnly | QIODevice::Text)){

            QTextStream data(&Play1);
            data << username1;
            data<<"\n";
            data << pass1;
            data<<"\n";
            data<<score1;
            data<<"\n";
            data <<newround<<"\n\n";

            if(newround%5==0)
            {

                QMessageBox msgBox;
                //    QMessageBox::StandardButton reply;
                msgBox.setStyleSheet("background : rgb(185, 154, 247)");
                msgBox.setText("Do You Want To Know The Correct Answer?");
                msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
                int reply1 = msgBox.exec();
                if (reply1 == QMessageBox::Yes) {
                    auto msgBox2 = new QMessageBox();
                    msgBox2->setMinimumSize(300, 300);
                    msgBox2->setStyleSheet("QMessageBox{background: rgb(185, 154, 247)}"
                                           "QPushButton{ background : rgb(185, 154, 247)}");
                    msgBox2->setText("Coming soon!");
                    msgBox2->exec();
                }

                QFile Play1("GamerData.txt");
                if (Play1.open(QIODevice::WriteOnly | QIODevice::Text)){

                    QTextStream data(&Play1);
                    data << username1;
                    data<<"\n";
                    data << pass1;
                    data<<"\n";
                    data<<score1;
                    data<<"\n\n";

                    QMessageBox msgBox;
                    msgBox.setText("You can check your score in Profile part!");
                    msgBox.exec();

                    hide();
                    ssub = new survSub(this);
                    ssub -> show();

                }
            }
        }
    }

    //-------------------------------

    if(newround%5!=0){

        QMessageBox msgBox;
        //    QMessageBox::StandardButton reply;
        msgBox.setStyleSheet("background : rgb(185, 154, 247)");
        msgBox.setText("Do You Want To Know The Correct Answer?");
        msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
        int reply1 = msgBox.exec();
        if (reply1 == QMessageBox::Yes) {
            auto msgBox2 = new QMessageBox();
            msgBox2->setMinimumSize(300, 300);
            msgBox2->setStyleSheet("QMessageBox{background: rgb(185, 154, 247)}"
                                   "QPushButton{ background : rgb(185, 154, 247)}");
            msgBox2->setText("Coming soon!");
            msgBox2->exec();
        }
        hide();
        surS2 = new survStart(this);
        surS2 -> show();
    }

}

void survgame::on_N4_clicked()
{
    timer->stop();


    M_Player = new QMediaPlayer();
    audioOutput = new QAudioOutput();
    M_Player -> setAudioOutput(audioOutput);
    M_Player -> setSource(QUrl("qrc:/sound/sounds/Download_Time_out_sound_effect_Royalty_Free_Music_&_Sound_Effects.mp4"));
    audioOutput->setVolume(0.5);
    M_Player -> play();

    //-----------------------------------
        QString username1;
        QString pass1;
        int score1;
        int round;
        int newround;

        QFile Play("Players.txt");
        if (Play.open(QIODevice::ReadWrite | QIODevice::Text)){

                QTextStream data(&Play);
                data>>username1;
                data>>pass1;
                data>>score1;
                data >> round;
                newround=round+1;
                score1++;


        QFile Play1("Players.txt");
        if (Play1.open(QIODevice::WriteOnly | QIODevice::Text)){

            QTextStream data(&Play1);
                data << username1;
                data<<"\n";
                data << pass1;
                data<<"\n";
                data<<score1;
                data<<"\n";
                data <<newround<<"\n\n";

                if(newround%3==0)
                {

                    QMessageBox msgBox;
                //    QMessageBox::StandardButton reply;
                            msgBox.setStyleSheet("background : rgb(185, 154, 247)");
                            msgBox.setText("Do You Want To Know The Correct Answer?");
                            msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
                           int reply1 = msgBox.exec();
                            if (reply1 == QMessageBox::Yes) {
                                auto msgBox2 = new QMessageBox();
                                msgBox2->setMinimumSize(300, 300);
                                msgBox2->setStyleSheet("QMessageBox{background: rgb(185, 154, 247)}"
                                                       "QPushButton{ background : rgb(185, 154, 247)}");
                                msgBox2->setText("Coming soon!");
                                msgBox2->exec();
                            }

                    QFile Play1("GamerData.txt");
                    if (Play1.open(QIODevice::WriteOnly | QIODevice::Text)){

                        QTextStream data(&Play1);
                            data << username1;
                            data<<"\n";
                            data << pass1;
                            data<<"\n";
                            data<<score1;
                            data<<"\n\n";

                    QMessageBox msgBox;
                       msgBox.setText("You can check your score in Profile part!");
                       msgBox.exec();

                       hide();
                       ssub = new survSub(this);
                       ssub -> show();

        }
        }
        }
        }

                //-------------------------------

if(newround%3!=0){

    QMessageBox msgBox;
//    QMessageBox::StandardButton reply;
            msgBox.setStyleSheet("background : rgb(185, 154, 247)");
            msgBox.setText("Do You Want To Know The Correct Answer?");
            msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
           int reply1 = msgBox.exec();
            if (reply1 == QMessageBox::Yes) {
                auto msgBox2 = new QMessageBox();
                msgBox2->setMinimumSize(300, 300);
                msgBox2->setStyleSheet("QMessageBox{background: rgb(185, 154, 247)}"
                                       "QPushButton{ background : rgb(185, 154, 247)}");
                msgBox2->setText("Coming soon!");
                msgBox2->exec();
            }
            hide();
            surS2 = new survStart(this);
            surS2 -> show();
}
}




