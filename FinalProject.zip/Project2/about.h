#ifndef ABOUT_H
#define ABOUT_H

#include <QDialog>
#include <QtMultimedia>
#include <QAudioOutput>

namespace Ui {
class about;
}

class about : public QDialog
{
    Q_OBJECT

public:
    explicit about(QWidget *parent = nullptr);
    ~about();

private slots:
    void on_back_clicked();

private:
    Ui::about *ui;
    QMediaPlayer *M_Player;
    QAudioOutput* audioOutput;
};

#endif // ABOUT_H
