#include "survival.h"
#include "ui_survival.h"
#include "mainwindow.h"
#include "survsub.h"
survSub *ssb;
MainWindow *mw1;

survival::survival(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::survival)
{
    ui->setupUi(this);
}

survival::~survival()
{
    delete ui;
}

void survival::on_pushButton_2_clicked()
{
    M_Player = new QMediaPlayer();
    audioOutput = new QAudioOutput();
    M_Player -> setAudioOutput(audioOutput);
    M_Player -> setSource(QUrl("qrc:/sound/sounds/ui-digital-button-click-gfx-sounds-1-00-00.mp3"));
     audioOutput->setVolume(0.5);
    M_Player -> play();


    QFile Play("Players.txt");
    if (Play.open(QIODevice::WriteOnly | QIODevice::Text)){

        QString username;
        QString pass;
        int score=0;

        username=ui -> user1_2 ->text();
        pass =  ui -> pass1_2 ->text();

            QTextStream data(&Play);
            data << ui -> user1_2 ->text();
            data<<"\n";
            data << ui -> pass1_2 ->text();
            data<<"\n";
            data<<score;
            data<<"\n";
            data <<"0"<<"\n\n";
}

//    QFile Data("GamerData.txt");
//    if (Data.open(QIODevice::Append  | QIODevice::ReadWrite)){

//        //------------------------------------------
//        QTextStream in(&Data);

//        QString nextWord;
//        QString word;
//        QString pword;
//        QString score;
//        QString space;
//        bool flag = true;

//        while (!in.atEnd()) {
//            in >> word;

//            if(word==username){
//                in >> pword;

//                if (pword==pass){

//                in<<"founded!";

//                }
//                }
//                }

//        if (flag){
//                 in << ui -> user1_2 ->text();
//                 in<<"\n";
//                 in << ui -> pass1_2 ->text();
//                 in<<"\n";
//                 in << "0"<<"\n\n";
//            }
//    }
//    Data.close();
//    }


//            QFile file("GamerData.txt");
//            if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
//                return;
//            QTextStream in(&file);

////            QString targetWord = "0724";
//            QString nextWord;

//            while (!in.atEnd()) {
//                QString word;
//                QString pword;
//                QString space;

//                in >> word;
//                if (word == username) {
//                    // Word found! Read the next word.
//                    in >>pword;
//                    if (pword == pass) {
//                    in >> nextWord;
//                    QString score;
//                    score = nextWord;
//                    ui->label_3->setText(score);



//                    break; // Exit the loop after finding the word
//                }
//            }
//        }
//            file.close();



    hide();
    ssb = new survSub(this);
    ssb -> show();
}


void survival::on_back_2_clicked()
{
    M_Player = new QMediaPlayer();
    audioOutput = new QAudioOutput();
    M_Player -> setAudioOutput(audioOutput);
    M_Player -> setSource(QUrl("qrc:/sound/sounds/ui-digital-button-click-gfx-sounds-1-00-00.mp3"));
     audioOutput->setVolume(0.5);
    M_Player -> play();
    hide();
    mw1 = new MainWindow(this);
    mw1 -> show();
}
