#ifndef PVPGAME_H
#define PVPGAME_H

#include <QDialog>
#include <QtMultimedia>
#include <QAudioOutput>
#include <QDateTime>
#include <QString>
#include <QTimer>
#include <QDebug>
#include <QMessageBox>


namespace Ui {
class pvpGame;
}

class pvpGame : public QDialog
{
    Q_OBJECT

public:
    explicit pvpGame(QWidget *parent = nullptr);
    ~pvpGame();

private slots:

    void updateCountdown();
    void prinQuestions();
    void on_Home_clicked();
    void on_finish_clicked();

//    void on_spinBox_valueChanged(int arg1);

private:
    Ui::pvpGame *ui;
    QMediaPlayer *M_Player;
    QAudioOutput* audioOutput;
    QTimer *timer;

};

#endif // PVPGAME_H
