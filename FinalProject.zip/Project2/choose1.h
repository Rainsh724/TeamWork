#ifndef CHOOSE1_H
#define CHOOSE1_H

#include <QDialog>
#include <QtMultimedia>
#include <QAudioOutput>
#include <QDateTime>
#include <QString>
#include <QTimer>
#include <QDebug>
#include <QMessageBox>

namespace Ui {
class Choose1;
}

class Choose1 : public QDialog
{
    Q_OBJECT

public:
    explicit Choose1(QWidget *parent = nullptr);
    ~Choose1();

private slots:
    void on_ch1_clicked();

    void on_ch2_clicked();

    void on_ch3_clicked();

    void on_ch4_clicked();

private:
    Ui::Choose1 *ui;
    QMediaPlayer *M_Player;
    QAudioOutput* audioOutput;
};

#endif // CHOOSE1_H
