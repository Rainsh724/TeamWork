#include "sub.h"
#include "ui_sub.h"
#include "pvpstart1.h"
#include "mainwindow.h"
MainWindow *mww;
pvpStart1 *pst1;

sub::sub(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::sub)
{
    ui->setupUi(this);
}

sub::~sub()
{
    delete ui;
}

void sub::on_General_clicked()
{
    QFile Play("sub.txt");
    if (Play.open(QIODevice::WriteOnly | QIODevice::Text)){
            QTextStream data(&Play);
            data << "9";
    }
    hide();
    pst1 = new pvpStart1(this);
    pst1 -> show();
}

void sub::on_Computer_clicked()
{
    QFile Play("sub.txt");
    if (Play.open(QIODevice::WriteOnly | QIODevice::Text)){
            QTextStream data(&Play);
            data << "18";
    }
    hide();
    pst1 = new pvpStart1(this);
    pst1 -> show();
}

void sub::on_Math_clicked()
{
    QFile Play("sub.txt");
    if (Play.open(QIODevice::WriteOnly | QIODevice::Text)){
            QTextStream data(&Play);
            data << "19";
    }
    hide();
    pst1 = new pvpStart1(this);
    pst1 -> show();
}

void sub::on_Art_clicked()
{
    QFile Play("sub.txt");
    if (Play.open(QIODevice::WriteOnly | QIODevice::Text)){
            QTextStream data(&Play);
            data << "25";
    }
    hide();
    pst1 = new pvpStart1(this);
    pst1 -> show();
}

void sub::on_History_clicked()
{
    QFile Play("sub.txt");
    if (Play.open(QIODevice::WriteOnly | QIODevice::Text)){
            QTextStream data(&Play);
            data << "23";
    }
    hide();
    pst1 = new pvpStart1(this);
    pst1 -> show();
}

void sub::on_Home_clicked()
{
    hide();
    mww = new MainWindow(this);
    mww -> show();
}
