#ifndef SURVGAME_H
#define SURVGAME_H

#include <QDialog>
#include <QtMultimedia>
#include <QAudioOutput>
#include <QDateTime>
#include <QString>
#include <QTimer>
#include <QDebug>
#include <QMessageBox>


namespace Ui {
class survgame;
}

class survgame : public QDialog
{
    Q_OBJECT

public:
    explicit survgame(QWidget *parent = nullptr);
    ~survgame();

private slots:
    void on_Home_clicked();
    void prinQuestions();
    void on_start_clicked();

    void updateCountdown();

    void on_N1_clicked();

    void on_N2_clicked();

    void on_N3_clicked();

    void on_N4_clicked();


private:
    Ui::survgame *ui;
    QMediaPlayer *M_Player;
    QAudioOutput* audioOutput;
    QTimer *timer;
};

#endif // SURVGAME_H
