#include "choose2.h"
#include "ui_choose2.h"
#include "pvpstart1.h"
#include "sub.h"
sub *s;
pvpStart1 *pvs2;

Choose2::Choose2(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Choose2)
{
    ui->setupUi(this);
}

Choose2::~Choose2()
{
    delete ui;
}

//***************************************************************************************

void Choose2::on_ch1_clicked()
{
    M_Player = new QMediaPlayer();
    audioOutput = new QAudioOutput();
    M_Player -> setAudioOutput(audioOutput);
    M_Player -> setSource(QUrl("qrc:/sound/sounds/Download_Time_out_sound_effect_Royalty_Free_Music_&_Sound_Effects.mp4"));
    audioOutput->setVolume(0.5);
    M_Player -> play();

    //-----------------------------------
        QString username1;
        QString username2;
        QString pass1;
        QString pass2;
        int score1;
        int score2;
        int round;
        int newround;

        QFile Play("Players.txt");
        if (Play.open(QIODevice::ReadWrite | QIODevice::Text)){

                QTextStream data(&Play);
                data>>username1;
                data>>pass1;
                data>>score1;
                data>>username2;
                data>>pass2;
                data>>score2;
                data >> round;
                newround=round+1;
//                score2++;


        QFile Play1("Players.txt");
        if (Play1.open(QIODevice::WriteOnly | QIODevice::Text)){

            QTextStream data(&Play1);
                data << username1;
                data<<"\n";
                data << pass1;
                data<<"\n";
                data<<score1;
                data<<"\n";

                data << username2;
                data<<"\n";
                data << pass2;
                data<<"\n";
                data<<score2;
                data<<"\n";
                data <<newround<<"\n\n";

                if(newround%5==0)
                {

                    QMessageBox msgBox;
                //    QMessageBox::StandardButton reply;
                            msgBox.setStyleSheet("background : rgb(185, 154, 247)");
                            msgBox.setText("Do You Want To Know The Correct Answer?");
                            msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
                           int reply1 = msgBox.exec();
                            if (reply1 == QMessageBox::Yes) {
                                auto msgBox2 = new QMessageBox();
                                msgBox2->setMinimumSize(300, 300);
                                msgBox2->setStyleSheet("QMessageBox{background: rgb(185, 154, 247)}"
                                                       "QPushButton{ background : rgb(185, 154, 247)}");
                                msgBox2->setText("Coming soon!");
                                msgBox2->exec();
                            }

                    QFile Play1("GamerData.txt");
                    if (Play1.open(QIODevice::WriteOnly | QIODevice::Text)){

                        QTextStream data(&Play1);
                            data << username1;
                            data<<"\n";
                            data << pass1;
                            data<<"\n";
                            data<<score1;
                            data<<"\n";

                            data << username2;
                            data<<"\n";
                            data << pass2;
                            data<<"\n";
                            data<<score2;
                            data<<"\n\n";


                    if(score2>score1)
                    {
                    QMessageBox msgBox;
                       msgBox.setText("Player 2 Wins!");
                       msgBox.exec();

                       hide();
                       s = new sub(this);
                       s -> show();
                }

                    if(score1>score2)
                    {
                        QMessageBox msgBox;
                           msgBox.setText("Player 1 Wins!");
                           msgBox.exec();

                           hide();
                           s = new sub(this);
                           s -> show();
                    }

                    if(score1==score2)
                    {
                        QMessageBox msgBox;
                           msgBox.setText("Both Of You Tied The Game!");
                           msgBox.exec();

                           hide();
                           s = new sub(this);
                           s -> show();
                    }
        }
        }
        }
        }

                //-------------------------------

if(newround%5!=0){

    QMessageBox msgBox;
//    QMessageBox::StandardButton reply;
            msgBox.setStyleSheet("background : rgb(185, 154, 247)");
            msgBox.setText("Do You Want To Know The Correct Answer?");
            msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
           int reply1 = msgBox.exec();
            if (reply1 == QMessageBox::Yes) {
                auto msgBox2 = new QMessageBox();
                msgBox2->setMinimumSize(300, 300);
                msgBox2->setStyleSheet("QMessageBox{background: rgb(185, 154, 247)}"
                                       "QPushButton{ background : rgb(185, 154, 247)}");
                msgBox2->setText("Coming soon!");
                msgBox2->exec();
            }
            hide();
            pvs2 = new pvpStart1(this);
            pvs2 -> show();
}

}


//**********************************************************************************


void Choose2::on_ch2_clicked()
{

    M_Player = new QMediaPlayer();
    audioOutput = new QAudioOutput();
    M_Player -> setAudioOutput(audioOutput);
    M_Player -> setSource(QUrl("qrc:/sound/sounds/Download_Time_out_sound_effect_Royalty_Free_Music_&_Sound_Effects.mp4"));
     audioOutput->setVolume(0.5);
    M_Player -> play();

    //-----------------------------------
        QString username1;
        QString username2;
        QString pass1;
        QString pass2;
        int score1;
        int score2;
        int round;
        int newround;

        QFile Play("Players.txt");
        if (Play.open(QIODevice::ReadWrite | QIODevice::Text)){

                QTextStream data(&Play);
                data>>username1;
                data>>pass1;
                data>>score1;
                data>>username2;
                data>>pass2;
                data>>score2;
                data >> round;
                newround=round+1;
//                score2++;


        QFile Play1("Players.txt");
        if (Play1.open(QIODevice::WriteOnly | QIODevice::Text)){

            QTextStream data(&Play1);
                data << username1;
                data<<"\n";
                data << pass1;
                data<<"\n";
                data<<score1;
                data<<"\n";

                data << username2;
                data<<"\n";
                data << pass2;
                data<<"\n";
                data<<score2;
                data<<"\n";
                data <<newround<<"\n\n";

                if(newround%5==0)
                {

                    QMessageBox msgBox;
                //    QMessageBox::StandardButton reply;
                            msgBox.setStyleSheet("background : rgb(185, 154, 247)");
                            msgBox.setText("Do You Want To Know The Correct Answer?");
                            msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
                           int reply1 = msgBox.exec();
                            if (reply1 == QMessageBox::Yes) {
                                auto msgBox2 = new QMessageBox();
                                msgBox2->setMinimumSize(300, 300);
                                msgBox2->setStyleSheet("QMessageBox{background: rgb(185, 154, 247)}"
                                                       "QPushButton{ background : rgb(185, 154, 247)}");
                                msgBox2->setText("Coming soon!");
                                msgBox2->exec();
                            }

                    QFile Play1("GamerData.txt");
                    if (Play1.open(QIODevice::WriteOnly | QIODevice::Text)){

                        QTextStream data(&Play1);
                            data << username1;
                            data<<"\n";
                            data << pass1;
                            data<<"\n";
                            data<<score1;
                            data<<"\n";

                            data << username2;
                            data<<"\n";
                            data << pass2;
                            data<<"\n";
                            data<<score2;
                            data<<"\n\n";


                    if(score2>score1)
                    {
                    QMessageBox msgBox;
                       msgBox.setText("Player 2 Wins!");
                       msgBox.exec();

                       hide();
                       s = new sub(this);
                       s -> show();
                }

                    if(score1>score2)
                    {
                        QMessageBox msgBox;
                           msgBox.setText("Player 1 Wins!");
                           msgBox.exec();

                           hide();
                           s = new sub(this);
                           s -> show();
                    }

                    if(score1==score2)
                    {
                        QMessageBox msgBox;
                           msgBox.setText("Both Of You Tied The Game!");
                           msgBox.exec();

                           hide();
                           s = new sub(this);
                           s -> show();
                    }
        }
        }
        }
        }

                //-------------------------------

if(newround%5!=0){

    QMessageBox msgBox;
//    QMessageBox::StandardButton reply;
            msgBox.setStyleSheet("background : rgb(185, 154, 247)");
            msgBox.setText("Do You Want To Know The Correct Answer?");
            msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
           int reply1 = msgBox.exec();
            if (reply1 == QMessageBox::Yes) {
                auto msgBox2 = new QMessageBox();
                msgBox2->setMinimumSize(300, 300);
                msgBox2->setStyleSheet("QMessageBox{background: rgb(185, 154, 247)}"
                                       "QPushButton{ background : rgb(185, 154, 247)}");
                msgBox2->setText("Coming soon!");
                msgBox2->exec();
            }
            hide();
            pvs2 = new pvpStart1(this);
            pvs2 -> show();
}
}


//****************************************************************************


void Choose2::on_ch3_clicked()
{

    M_Player = new QMediaPlayer();
    audioOutput = new QAudioOutput();
    M_Player -> setAudioOutput(audioOutput);
    M_Player -> setSource(QUrl("qrc:/sound/sounds/Download_Time_out_sound_effect_Royalty_Free_Music_&_Sound_Effects.mp4"));
     audioOutput->setVolume(0.5);
    M_Player -> play();

    //-----------------------------------
        QString username1;
        QString username2;
        QString pass1;
        QString pass2;
        int score1;
        int score2;
        int round;
        int newround;

        QFile Play("Players.txt");
        if (Play.open(QIODevice::ReadWrite | QIODevice::Text)){

                QTextStream data(&Play);
                data>>username1;
                data>>pass1;
                data>>score1;
                data>>username2;
                data>>pass2;
                data>>score2;
                data >> round;
                newround=round+1;
//                score2++;


        QFile Play1("Players.txt");
        if (Play1.open(QIODevice::WriteOnly | QIODevice::Text)){

            QTextStream data(&Play1);
                data << username1;
                data<<"\n";
                data << pass1;
                data<<"\n";
                data<<score1;
                data<<"\n";

                data << username2;
                data<<"\n";
                data << pass2;
                data<<"\n";
                data<<score2;
                data<<"\n";
                data <<newround<<"\n\n";

                if(newround%5==0)
                {

                    QMessageBox msgBox;
                //    QMessageBox::StandardButton reply;
                            msgBox.setStyleSheet("background : rgb(185, 154, 247)");
                            msgBox.setText("Do You Want To Know The Correct Answer?");
                            msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
                           int reply1 = msgBox.exec();
                            if (reply1 == QMessageBox::Yes) {
                                auto msgBox2 = new QMessageBox();
                                msgBox2->setMinimumSize(300, 300);
                                msgBox2->setStyleSheet("QMessageBox{background: rgb(185, 154, 247)}"
                                                       "QPushButton{ background : rgb(185, 154, 247)}");
                                msgBox2->setText("Coming soon!");
                                msgBox2->exec();
                            }

                    QFile Play1("GamerData.txt");
                    if (Play1.open(QIODevice::WriteOnly | QIODevice::Text)){

                        QTextStream data(&Play1);
                            data << username1;
                            data<<"\n";
                            data << pass1;
                            data<<"\n";
                            data<<score1;
                            data<<"\n";

                            data << username2;
                            data<<"\n";
                            data << pass2;
                            data<<"\n";
                            data<<score2;
                            data<<"\n\n";


                    if(score2>score1)
                    {
                    QMessageBox msgBox;
                       msgBox.setText("Player 2 Wins!");
                       msgBox.exec();

                       hide();
                       s = new sub(this);
                       s -> show();
                }

                    if(score1>score2)
                    {
                        QMessageBox msgBox;
                           msgBox.setText("Player 1 Wins!");
                           msgBox.exec();

                           hide();
                           s = new sub(this);
                           s -> show();
                    }

                    if(score1==score2)
                    {
                        QMessageBox msgBox;
                           msgBox.setText("Both Of You Tied The Game!");
                           msgBox.exec();

                           hide();
                           s = new sub(this);
                           s -> show();
                    }
        }
        }
        }
        }

                //-------------------------------

if(newround%5!=0){

    QMessageBox msgBox;
//    QMessageBox::StandardButton reply;
            msgBox.setStyleSheet("background : rgb(185, 154, 247)");
            msgBox.setText("Do You Want To Know The Correct Answer?");
            msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
           int reply1 = msgBox.exec();
            if (reply1 == QMessageBox::Yes) {
                auto msgBox2 = new QMessageBox();
                msgBox2->setMinimumSize(300, 300);
                msgBox2->setStyleSheet("QMessageBox{background: rgb(185, 154, 247)}"
                                       "QPushButton{ background : rgb(185, 154, 247)}");
                msgBox2->setText("Coming soon!");
                msgBox2->exec();
            }
            hide();
            pvs2 = new pvpStart1(this);
            pvs2 -> show();
}
}

//**********************************************************************************************


void Choose2::on_ch4_clicked()
{
    M_Player = new QMediaPlayer();
    audioOutput = new QAudioOutput();
    M_Player -> setAudioOutput(audioOutput);
    M_Player -> setSource(QUrl("qrc:/sound/sounds/Download_Time_out_sound_effect_Royalty_Free_Music_&_Sound_Effects.mp4"));
     audioOutput->setVolume(0.5);
    M_Player -> play();

    //-----------------------------------
        QString username1;
        QString username2;
        QString pass1;
        QString pass2;
        int score1;
        int score2;
        int round;
        int newround;

        QFile Play("Players.txt");
        if (Play.open(QIODevice::ReadWrite | QIODevice::Text)){

                QTextStream data(&Play);
                data>>username1;
                data>>pass1;
                data>>score1;
                data>>username2;
                data>>pass2;
                data>>score2;
                data >> round;
                newround=round+1;
                score2++;


        QFile Play1("Players.txt");
        if (Play1.open(QIODevice::WriteOnly | QIODevice::Text)){

            QTextStream data(&Play1);
                data << username1;
                data<<"\n";
                data << pass1;
                data<<"\n";
                data<<score1;
                data<<"\n";

                data << username2;
                data<<"\n";
                data << pass2;
                data<<"\n";
                data<<score2;
                data<<"\n";
                data <<newround<<"\n\n";

                if(newround%5==0)
                {

                    QMessageBox msgBox;
                //    QMessageBox::StandardButton reply;
                            msgBox.setStyleSheet("background : rgb(185, 154, 247)");
                            msgBox.setText("Do You Want To Know The Correct Answer?");
                            msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
                           int reply1 = msgBox.exec();
                            if (reply1 == QMessageBox::Yes) {
                                auto msgBox2 = new QMessageBox();
                                msgBox2->setMinimumSize(300, 300);
                                msgBox2->setStyleSheet("QMessageBox{background: rgb(185, 154, 247)}"
                                                       "QPushButton{ background : rgb(185, 154, 247)}");
                                msgBox2->setText("Coming soon!");
                                msgBox2->exec();
                            }

                    QFile Play1("GamerData.txt");
                    if (Play1.open(QIODevice::WriteOnly | QIODevice::Text)){

                        QTextStream data(&Play1);
                            data << username1;
                            data<<"\n";
                            data << pass1;
                            data<<"\n";
                            data<<score1;
                            data<<"\n";

                            data << username2;
                            data<<"\n";
                            data << pass2;
                            data<<"\n";
                            data<<score2;
                            data<<"\n\n";


                    if(score2>score1)
                    {
                    QMessageBox msgBox;
                       msgBox.setText("Player 2 Wins!");
                       msgBox.exec();

                       hide();
                       s = new sub(this);
                       s -> show();
                }

                    if(score1>score2)
                    {
                        QMessageBox msgBox;
                           msgBox.setText("Player 1 Wins!");
                           msgBox.exec();

                           hide();
                           s = new sub(this);
                           s -> show();
                    }

                    if(score1==score2)
                    {
                        QMessageBox msgBox;
                           msgBox.setText("Both Of You Tied The Game!");
                           msgBox.exec();

                           hide();
                           s = new sub(this);
                           s -> show();
                    }
        }
        }
        }
        }

                //-------------------------------

if(newround%5!=0){

    QMessageBox msgBox;
//    QMessageBox::StandardButton reply;
            msgBox.setStyleSheet("background : rgb(185, 154, 247)");
            msgBox.setText("Do You Want To Know The Correct Answer?");
            msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
           int reply1 = msgBox.exec();
            if (reply1 == QMessageBox::Yes) {
                auto msgBox2 = new QMessageBox();
                msgBox2->setMinimumSize(300, 300);
                msgBox2->setStyleSheet("QMessageBox{background: rgb(185, 154, 247)}"
                                       "QPushButton{ background : rgb(185, 154, 247)}");
                msgBox2->setText("Coming soon!");
                msgBox2->exec();
            }
            hide();
            pvs2 = new pvpStart1(this);
            pvs2 -> show();
}
}
