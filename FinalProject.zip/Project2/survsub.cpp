#include "survsub.h"
#include "ui_survsub.h"
#include "survstart.h"
#include "mainwindow.h"
MainWindow *mww2;
survStart *sst;

survSub::survSub(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::survSub)
{
    ui->setupUi(this);
}

survSub::~survSub()
{
    delete ui;
}

void survSub::on_General_clicked()
{
    QFile Play("sub.txt");
    if (Play.open(QIODevice::WriteOnly | QIODevice::Text)){
            QTextStream data(&Play);
            data << "9";
    }
    hide();
    sst = new survStart(this);
    sst -> show();
}

void survSub::on_Computer_clicked()
{
    QFile Play("sub.txt");
    if (Play.open(QIODevice::WriteOnly | QIODevice::Text)){
            QTextStream data(&Play);
            data << "18";
    }
    hide();
    sst = new survStart(this);
    sst -> show();
}

void survSub::on_Math_clicked()
{
    QFile Play("sub.txt");
    if (Play.open(QIODevice::WriteOnly | QIODevice::Text)){
            QTextStream data(&Play);
            data << "19";
    }
    hide();
    sst = new survStart(this);
    sst -> show();
}

void survSub::on_Art_clicked()
{
    QFile Play("sub.txt");
    if (Play.open(QIODevice::WriteOnly | QIODevice::Text)){
            QTextStream data(&Play);
            data << "25";
    }
    hide();
    sst = new survStart(this);
    sst -> show();
}

void survSub::on_History_clicked()
{    QFile Play("sub.txt");
     if (Play.open(QIODevice::WriteOnly | QIODevice::Text)){
             QTextStream data(&Play);
             data << "23";
     }
     hide();
     sst = new survStart(this);
     sst -> show();

}

void survSub::on_Home_clicked()
{
    hide();
    mww2 = new MainWindow(this);
    mww2 -> show();
}
