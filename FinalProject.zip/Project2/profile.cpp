#include "profile.h"
#include "ui_profile.h"
#include "mainwindow.h"
MainWindow *mw2;

profile::profile(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::profile)
{
    ui->setupUi(this);
}

profile::~profile()
{
    delete ui;
}

void profile::on_back_clicked()
{

    M_Player = new QMediaPlayer();
    audioOutput = new QAudioOutput();
    M_Player -> setAudioOutput(audioOutput);
    M_Player -> setSource(QUrl("qrc:/sound/sounds/ui-digital-button-click-gfx-sounds-1-00-00.mp3"));
     audioOutput->setVolume(0.5);
    M_Player -> play();
    hide();
    mw2 = new MainWindow(this);
    mw2 -> show();
}

void profile::on_score_clicked()
{

    QString username;
    QString pass;

    username=ui -> lineEdit ->text();
    pass =  ui -> lineEdit_2 ->text();

    QFile file("GamerData.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return;
    QTextStream in(&file);

    QString nextWord;

    while (!in.atEnd()) {
        QString word;
        QString pword;

        in >> word;
        if (word == username) {
            // Word found! Read the next word.
            in >>pword;
            if (pword == pass) {
            in >> nextWord;
            QString score;
            score = nextWord;
            ui->label_3->setText(score);



            break; // Exit the loop after finding the word
        }
    }
}
    file.close();
}
