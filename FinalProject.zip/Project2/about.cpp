#include "about.h"
#include "ui_about.h"
#include "mainwindow.h"
MainWindow *mw3;

about::about(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::about)
{
    ui->setupUi(this);
}

about::~about()
{
    delete ui;
}

void about::on_back_clicked()
{
    M_Player = new QMediaPlayer();
    audioOutput = new QAudioOutput();
    M_Player -> setAudioOutput(audioOutput);
    M_Player -> setSource(QUrl("qrc:/sound/sounds/ui-digital-button-click-gfx-sounds-1-00-00.mp3"));
    audioOutput->setVolume(0.5);
    M_Player -> play();
    hide();

    mw3 = new MainWindow(this);
    mw3 -> show();
}
