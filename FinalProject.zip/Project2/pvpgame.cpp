#include "pvpgame.h"
#include "ui_pvpgame.h"
#include "mainwindow.h"
#include "pvpstart1.h"
#include "choose1.h"

MainWindow *mw4;
Choose1 *cho1;


pvpGame::pvpGame(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::pvpGame)
{
    ui->setupUi(this);


    QFile file("sub.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return;
    QTextStream in(&file);
        int num;
        in >> num;

    pvpGame::prinQuestions();

    ui->countdown->setText("0:30");
    timer = new QTimer();
     connect(timer, SIGNAL(timeout()), this, SLOT(updateCountdown()));
     timer->start(1000);


}

pvpGame::~pvpGame()
{
    delete ui;
}


void pvpGame::on_Home_clicked()
{
    timer ->stop();
    M_Player = new QMediaPlayer();
    audioOutput = new QAudioOutput();
    M_Player -> setAudioOutput(audioOutput);
    M_Player -> setSource(QUrl("qrc:/sound/sounds/ui-digital-button-click-gfx-sounds-1-00-00.mp3"));
     audioOutput->setVolume(0.5);
    M_Player -> play();
    hide();
    mw4 = new MainWindow(this);
    mw4 -> show();
}


void pvpGame::updateCountdown()
{
    static int remainingSeconds = 30;
        remainingSeconds--;

        int minutes = remainingSeconds / 30;
        int seconds = remainingSeconds % 30;
        ui->countdown->setText(QString("%1:%2").arg(minutes).arg(seconds, 2, 10, QChar('0')));

    QMessageBox msgBox;
    QMessageBox::StandardButton reply;
        if (remainingSeconds == 0)
            {
            timer->stop();
            M_Player = new QMediaPlayer();
            audioOutput = new QAudioOutput();
            M_Player -> setAudioOutput(audioOutput);
            M_Player -> setSource(QUrl("qrc:/sound/sounds/Download_Time_out_sound_effect_Royalty_Free_Music_&_Sound_Effects.mp4"));
             audioOutput->setVolume(0.5);
            M_Player -> play();
            hide();
            cho1 = new Choose1(this);
            cho1 -> show();
            }
        }


void pvpGame::on_finish_clicked()
{
    timer->stop();
    M_Player = new QMediaPlayer();
    audioOutput = new QAudioOutput();
    M_Player -> setAudioOutput(audioOutput);
    M_Player -> setSource(QUrl("qrc:/sound/sounds/Download_Time_out_sound_effect_Royalty_Free_Music_&_Sound_Effects.mp4"));
     audioOutput->setVolume(0.5);
    M_Player -> play();

    hide();
    cho1 = new Choose1(this);
    cho1 -> show();
}

void pvpGame::prinQuestions()
{
    QString question;
    QString correct;
    QString incorrect1;
    QString incorrect2;
    QString incorrect3;
    QFile Readquestions("questios.txt");
    if (Readquestions.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        QTextStream readq(&Readquestions);
        readq>>question;
        readq>>incorrect1;
        readq>>incorrect2;
        readq>>incorrect3;
        readq>>correct;



    //print data

    ui->question->setText(question);
    ui->answer1->setText(correct);
    ui->answer2->setText(incorrect1);
    ui->answer3->setText(incorrect2);
    ui->answer4->setText(incorrect3);
    }
}
