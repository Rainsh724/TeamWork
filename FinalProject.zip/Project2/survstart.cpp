#include "survstart.h"
#include "ui_survstart.h"
#include "survgame.h"
#include "mainwindow.h"
MainWindow *mw9;
survgame *surG;

survStart::survStart(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::survStart)
{
    ui->setupUi(this);
}

survStart::~survStart()
{
    delete ui;
}

void survStart::on_start_clicked()
{
    survStart::fetchQuestions();
    hide();
    surG = new survgame(this);
    surG -> show();
}

void survStart::on_Home_clicked()
{
    M_Player = new QMediaPlayer();
    audioOutput = new QAudioOutput();
    M_Player -> setAudioOutput(audioOutput);
    M_Player -> setSource(QUrl("qrc:/sound/sounds/ui-digital-button-click-gfx-sounds-1-00-00.mp3"));
     audioOutput->setVolume(0.5);
    M_Player -> play();
    hide();
    mw9 = new MainWindow(this);
    mw9 -> show();
}

void survStart::fetchQuestions()
{
    int sub;
    QNetworkAccessManager *manager =  new QNetworkAccessManager(this);
    connect(manager , &QNetworkAccessManager::finished , this , &survStart::handleResponse);

    //------------------------

    QFile Subject("sub.txt");
    if (Subject.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        QTextStream subject(&Subject);
        subject>>sub;
    }

    QString category = QString::number(sub);
    QString api = "https://opentdb.com/api.php?amount=1&category=" + category + "&type=multiple";

    //-------------------------

    QUrl url(api);
    QNetworkRequest request(url);
    manager->get(request);
}
void survStart::handleResponse(QNetworkReply *reply)
{
    if (reply->error() == QNetworkReply::NoError)
    {
        QByteArray data = reply->readAll();
        QJsonDocument doc = QJsonDocument::fromJson(data);

        if (doc.isObject())
        {
            QJsonObject obj = doc.object();

            if (obj.contains("results") && obj["results"].isArray())
            {
                QJsonArray results = obj["results"].toArray();

                QStringList questionsList;
                QStringList correctAnswersList;
                QList<QStringList> incorrectAnswersList;
                for (const QJsonValue &result : results)
                {
                    QJsonObject questionObj = result.toObject();
                    QString question = questionObj["question"].toString();
                    questionsList.append(question);

                    QString correctAnswer = questionObj["correct_answer"].toString();
                    correctAnswersList.append(correctAnswer);

                    QJsonArray incorrectAnswersArray = questionObj["incorrect_answers"].toArray();
                    QStringList incorrectAnswers;
                    for (const QJsonValue &incorrectAnswer : incorrectAnswersArray)
                    {
                        incorrectAnswers.append(incorrectAnswer.toString());
                    }
                    incorrectAnswersList.append(incorrectAnswers);
                }
                QFile questionfile("questions.txt");
                if (questionfile.open(QIODevice::WriteOnly | QIODevice::Text))
                {
                    QTextStream question_p (&questionfile);
                    question_p<<questionsList[0]<<"\n";
                    question_p<<incorrectAnswersList[0][0]<<"\n";
                    question_p<<incorrectAnswersList[0][1]<<"\n";
                    question_p<<incorrectAnswersList[0][2]<<"\n";
                    question_p<<correctAnswersList[0]<<"\n";
                }


            }

        }

    }


    reply->deleteLater();
}
