#ifndef SURVIVAL_H
#define SURVIVAL_H

#include <QtMultimedia>
#include <QAudioOutput>
#include <QDialog>
#include <QFileDialog>
#include <QTextStream>
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonValue>
#include <QDebug>
#include <QDialog>
#include <QSpinBox>
#include <QTextEdit>
#include <QComboBox>
#include <QPushButton>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QFile>
#include <QIODevice>
#include <QTextStream>
#include <QtDebug>
#include <QDir>
#include <QString>

#include "survgame.h"

namespace Ui {
class survival;
}

class survival : public QDialog
{
    Q_OBJECT

public:
    explicit survival(QWidget *parent = nullptr);
    ~survival();

private slots:
    void on_pushButton_2_clicked();

    void on_back_2_clicked();

private:
    Ui::survival *ui;
    QMediaPlayer *M_Player;
    QAudioOutput* audioOutput;
};

#endif // SURVIVAL_H
