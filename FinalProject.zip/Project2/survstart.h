#ifndef SURVSTART_H
#define SURVSTART_H

#include <QDialog>
#include <QtMultimedia>
#include <QAudioOutput>
#include <QDialog>
#include <QtMultimedia>
#include <QAudioOutput>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QDebug>
#include <QFile>
#include <QUrl>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QListWidget>
#include <QListWidgetItem>

namespace Ui {
class survStart;
}

class survStart : public QDialog
{
    Q_OBJECT

public:
    explicit survStart(QWidget *parent = nullptr);
    ~survStart();

private slots:
    void on_start_clicked();
    void fetchQuestions();
    void handleResponse(QNetworkReply *reply);
    void on_Home_clicked();

private:
    Ui::survStart *ui;
    QMediaPlayer *M_Player;
    QAudioOutput* audioOutput;
};

#endif // SURVSTART_H
