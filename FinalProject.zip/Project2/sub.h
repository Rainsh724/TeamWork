#ifndef SUB_H
#define SUB_H

#include <QDialog>
#include <QFile>
#include <QFileDialog>
#include <QTextStream>

namespace Ui {
class sub;
}

class sub : public QDialog
{
    Q_OBJECT

public:
    explicit sub(QWidget *parent = nullptr);
    ~sub();

private slots:
    void on_pushButton_clicked();

    void on_General_clicked();

    void on_Computer_clicked();

    void on_Math_clicked();

    void on_Art_clicked();

    void on_History_clicked();

    void on_Home_clicked();

private:
    Ui::sub *ui;
};

#endif // SUB_H
