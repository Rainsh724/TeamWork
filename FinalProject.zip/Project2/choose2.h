#ifndef CHOOSE2_H
#define CHOOSE2_H

#include <QDialog>
#include <QtMultimedia>
#include <QAudioOutput>
#include <QDateTime>
#include <QString>
#include <QTimer>
#include <QDebug>
#include <QMessageBox>

namespace Ui {
class Choose2;
}

class Choose2 : public QDialog
{
    Q_OBJECT

public:
    explicit Choose2(QWidget *parent = nullptr);
    ~Choose2();

private slots:
    void on_ch1_clicked();

    void on_ch2_clicked();

    void on_ch3_clicked();

    void on_ch4_clicked();

private:
    Ui::Choose2 *ui;
        QMediaPlayer *M_Player;
    QAudioOutput* audioOutput;
};

#endif // CHOOSE2_H
