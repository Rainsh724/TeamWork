#ifndef SURVSUB_H
#define SURVSUB_H

#include <QDialog>

namespace Ui {
class survSub;
}

class survSub : public QDialog
{
    Q_OBJECT

public:
    explicit survSub(QWidget *parent = nullptr);
    ~survSub();

private slots:
    void on_General_clicked();

    void on_Computer_clicked();

    void on_Math_clicked();

    void on_Art_clicked();

    void on_History_clicked();

    void on_Home_clicked();

private:
    Ui::survSub *ui;
};

#endif // SURVSUB_H
