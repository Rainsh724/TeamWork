#include "pvplogin.h"
#include "ui_pvplogin.h"
#include "sub.h"
#include "mainwindow.h"
MainWindow *mw;
sub *su1;

PvPLogIn::PvPLogIn(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::PvPLogIn)
{
    ui->setupUi(this);
}

PvPLogIn::~PvPLogIn()
{
    delete ui;
}

void PvPLogIn::on_pushButton_clicked()
{
    M_Player = new QMediaPlayer();
    audioOutput = new QAudioOutput();
    M_Player -> setAudioOutput(audioOutput);
    M_Player -> setSource(QUrl("qrc:/sound/sounds/ui-digital-button-click-gfx-sounds-1-00-00.mp3"));
     audioOutput->setVolume(0.5);
    M_Player -> play();

    //-----------------------------------------

    QFile Play("Players.txt");
    if (Play.open(QIODevice::WriteOnly | QIODevice::Text)){

        QString username1;
        QString username2;
        QString pass1;
        QString pass2;
        int score1=0;
        int score2=0;

        username1=ui -> user1 ->text();
        pass1 =  ui -> pass1 ->text();
        username2=ui -> user2 ->text();
        pass2 =  ui -> pass2 ->text();

            QTextStream data(&Play);
            data << ui -> user1 ->text();
            data<<"\n";
            data << ui -> pass1 ->text();
            data<<"\n";
            data <<score1;
            data<<"\n";

            data << ui -> user2 ->text();
            data<<"\n";
            data << ui -> pass2 ->text();
            data<<"\n";
            data<<score2;
            data<<"\n";

            data <<"0"<<"\n\n";
    }

            //----------------------------------------

    QFile Data("GamerData.txt");
    if (Data.open(QIODevice::Append  | QIODevice::ReadWrite)){
        QTextStream stream(&Data);
        stream << ui -> user1 ->text();
        stream<<"\n";
        stream << ui -> pass1 ->text();
        stream<<"\n\n";
        stream << ui -> user2 ->text();
        stream<<"\n";
        stream << ui -> pass2 ->text();
        stream<<"\n\n";
    }
    Data.close();

    hide();
    su1 = new sub(this);
    su1 -> show();
}

void PvPLogIn::on_back_clicked()
{
    M_Player = new QMediaPlayer();
    audioOutput = new QAudioOutput();
    M_Player -> setAudioOutput(audioOutput);
    M_Player -> setSource(QUrl("qrc:/sound/sounds/ui-digital-button-click-gfx-sounds-1-00-00.mp3"));
     audioOutput->setVolume(0.5);
    M_Player -> play();
    hide();
    mw = new MainWindow(this);
    mw -> show();
}
