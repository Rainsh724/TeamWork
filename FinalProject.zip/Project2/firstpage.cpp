#include "firstpage.h"
#include "ui_firstpage.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"
FirstPage::FirstPage(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::FirstPage)
{
    ui->setupUi(this);
}

FirstPage::~FirstPage()
{
    delete ui;
}

void FirstPage::on_pushButton_clicked()
{
    hide();
    mainwindow = new mainwindow(this);
    mainwindow -> show();
}
