#ifndef PVPLOGIN_H
#define PVPLOGIN_H

#include <QtMultimedia>
#include <QAudioOutput>
#include <QDialog>
#include <QFileDialog>
#include <QTextStream>
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonValue>
#include <QDebug>
#include <QDialog>
#include <QSpinBox>
#include <QTextEdit>
#include <QComboBox>
#include <QPushButton>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QFile>
#include <QIODevice>
#include <QTextStream>
#include <QtDebug>
#include <QDir>
#include <QString>

#include "pvpgame.h"


namespace Ui {
class PvPLogIn;
}

class PvPLogIn : public QDialog
{
    Q_OBJECT

public:
    explicit PvPLogIn(QWidget *parent = nullptr);
    ~PvPLogIn();

private slots:
    void on_pushButton_clicked();

    void on_back_clicked();

private:
    Ui::PvPLogIn *ui;
    QMediaPlayer *M_Player;
    QAudioOutput* audioOutput;
    pvpGame *pvp1;
};

#endif // PVPLOGIN_H
