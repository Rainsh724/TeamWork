#include "pvpstart1.h"
#include "ui_pvpstart1.h"
#include "pvpgame.h"
#include "mainwindow.h"
MainWindow *mw8;
pvpGame *pvp1;

pvpStart1::pvpStart1(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::pvpStart1)
{
    ui->setupUi(this);

}

pvpStart1::~pvpStart1()
{
    delete ui;
}

void pvpStart1::on_start_clicked()
{
    pvpStart1::fetchQuestions();
    hide();
    pvp1 = new pvpGame(this);
    pvp1 -> show();
}


void pvpStart1::on_Home_clicked()
{
    M_Player = new QMediaPlayer();
    audioOutput = new QAudioOutput();
    M_Player -> setAudioOutput(audioOutput);
    M_Player -> setSource(QUrl("qrc:/sound/sounds/ui-digital-button-click-gfx-sounds-1-00-00.mp3"));
     audioOutput->setVolume(0.5);
    M_Player -> play();
    hide();
    mw8 = new MainWindow(this);
    mw8 -> show();
}

void pvpStart1::fetchQuestions()
{
    int sub;
    QNetworkAccessManager *manager =  new QNetworkAccessManager(this);
    connect(manager , &QNetworkAccessManager::finished , this , &pvpStart1::handleResponse);

    //------------------------

        QFile Subject("sub.txt");
        if (Subject.open(QIODevice::ReadOnly | QIODevice::Text))
        {
        QTextStream subject(&Subject);
        subject>>sub;
        }

        QString category = QString::number(sub);
        QString api = "https://opentdb.com/api.php?amount=1&category=" + category + "&type=multiple";

    //-------------------------

    QUrl url(api);
    QNetworkRequest request(url);
    manager->get(request);
}
void pvpStart1::handleResponse(QNetworkReply *reply)
{
    if (reply->error() == QNetworkReply::NoError)
    {
        QByteArray data = reply->readAll();
        QJsonDocument doc = QJsonDocument::fromJson(data);

        if (doc.isObject())
        {
            QJsonObject obj = doc.object();

            if (obj.contains("results") && obj["results"].isArray())
            {
                QJsonArray results = obj["results"].toArray();

                QStringList questionsList;
                QStringList correctAnswersList;
                QList<QStringList> incorrectAnswersList;
                for (const QJsonValue &result : results)
                {
                    QJsonObject questionObj = result.toObject();
                    QString question = questionObj["question"].toString();
                    questionsList.append(question);

                    QString correctAnswer = questionObj["correct_answer"].toString();
                    correctAnswersList.append(correctAnswer);

                    QJsonArray incorrectAnswersArray = questionObj["incorrect_answers"].toArray();
                    QStringList incorrectAnswers;
                    for (const QJsonValue &incorrectAnswer : incorrectAnswersArray)
                    {
                        incorrectAnswers.append(incorrectAnswer.toString());
                    }
                    incorrectAnswersList.append(incorrectAnswers);
                }
                QFile questionfile("questions.txt");
                    if (questionfile.open(QIODevice::WriteOnly | QIODevice::Text))
                    {
                        QTextStream question_p (&questionfile);
                        question_p<<questionsList[0]<<"\n";
                        question_p<<incorrectAnswersList[0][0]<<"\n";
                        question_p<<incorrectAnswersList[0][1]<<"\n";
                        question_p<<incorrectAnswersList[0][2]<<"\n";
                        question_p<<correctAnswersList[0]<<"\n";
                    }


                    }

            }

        }


        reply->deleteLater();
    }
