#include "choose1.h"
#include "ui_choose1.h"
#include "choose2.h"

Choose2 *cho2;

Choose1::Choose1(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Choose1)
{
    ui->setupUi(this);
}

Choose1::~Choose1()
{
    delete ui;
}

void Choose1::on_ch1_clicked()
{

    QString username1;
    QString username2;
    QString pass1;
    QString pass2;
    int score1;
    int score2;
    int round;
    int newround;

    QFile Play("Players.txt");
    if (Play.open(QIODevice::ReadWrite | QIODevice::Text)){

            QTextStream data(&Play);
            data>>username1;
            data>>pass1;
            data>>score1;
            data>>username2;
            data>>pass2;
            data>>score2;
            data >> round;
            newround=round+1;
//                score1++;


    QFile Play1("Players.txt");
    if (Play1.open(QIODevice::WriteOnly | QIODevice::Text)){

        QTextStream data(&Play1);
            data << username1;
            data<<"\n";
            data << pass1;
            data<<"\n";
            data<<score1;
            data<<"\n";

            data << username2;
            data<<"\n";
            data << pass2;
            data<<"\n";
            data<<score2;
            data<<"\n";
            data <<newround<<"\n\n";
}
    }
    QMessageBox msgBox;
//    QMessageBox::StandardButton reply;
            msgBox.setStyleSheet("background : rgb(185, 154, 247)");
            msgBox.setText("Do You Want To Know The Correct Answer?");
            msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
           int reply1 = msgBox.exec();
            if (reply1 == QMessageBox::Yes) {
                auto msgBox2 = new QMessageBox();
                msgBox2->setMinimumSize(300, 300);
                msgBox2->setStyleSheet("QMessageBox{background: rgb(185, 154, 247)}"
                                       "QPushButton{ background : rgb(185, 154, 247)}");
                msgBox2->setText("Coming soon!");
                msgBox2->exec();
            }
            M_Player = new QMediaPlayer();
            audioOutput = new QAudioOutput();
            M_Player -> setAudioOutput(audioOutput);
            M_Player -> setSource(QUrl("qrc:/sound/sounds/Download_Time_out_sound_effect_Royalty_Free_Music_&_Sound_Effects.mp4"));
            audioOutput->setVolume(0.5);;
            M_Player -> play();
            hide();
            cho2 = new Choose2(this);
            cho2 -> show();
}

void Choose1::on_ch2_clicked()
{

    QString username1;
    QString username2;
    QString pass1;
    QString pass2;
    int score1;
    int score2;
    int round;
    int newround;

    QFile Play("Players.txt");
    if (Play.open(QIODevice::ReadWrite | QIODevice::Text)){

            QTextStream data(&Play);
            data>>username1;
            data>>pass1;
            data>>score1;
            data>>username2;
            data>>pass2;
            data>>score2;
            data >> round;
            newround=round+1;
//                score1++;


    QFile Play1("Players.txt");
    if (Play1.open(QIODevice::WriteOnly | QIODevice::Text)){

        QTextStream data(&Play1);
            data << username1;
            data<<"\n";
            data << pass1;
            data<<"\n";
            data<<score1;
            data<<"\n";

            data << username2;
            data<<"\n";
            data << pass2;
            data<<"\n";
            data<<score2;
            data<<"\n";
            data <<newround<<"\n\n";
}
}

    QMessageBox msgBox;
//    QMessageBox::StandardButton reply;
            msgBox.setStyleSheet("background : rgb(185, 154, 247)");
            msgBox.setText("Do You Want To Know The Correct Answer?");
            msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
           int reply1 = msgBox.exec();
            if (reply1 == QMessageBox::Yes) {
                auto msgBox2 = new QMessageBox();
                msgBox2->setMinimumSize(300, 300);
                msgBox2->setStyleSheet("QMessageBox{background: rgb(185, 154, 247)}"
                                       "QPushButton{ background : rgb(185, 154, 247)}");
                msgBox2->setText("Coming soon!");
                msgBox2->exec();
            }

            M_Player = new QMediaPlayer();
            audioOutput = new QAudioOutput();
            M_Player -> setAudioOutput(audioOutput);
            M_Player -> setSource(QUrl("qrc:/sound/sounds/Download_Time_out_sound_effect_Royalty_Free_Music_&_Sound_Effects.mp4"));
            audioOutput->setVolume(0.5);
            M_Player -> play();
            hide();
            cho2 = new Choose2(this);
            cho2 -> show();
}

void Choose1::on_ch3_clicked()
{

    QString username1;
    QString username2;
    QString pass1;
    QString pass2;
    int score1;
    int score2;
    int round;
    int newround;

    QFile Play("Players.txt");
    if (Play.open(QIODevice::ReadWrite | QIODevice::Text)){

            QTextStream data(&Play);
            data>>username1;
            data>>pass1;
            data>>score1;
            data>>username2;
            data>>pass2;
            data>>score2;
            data >> round;
            newround=round+1;
//                score1++;


    QFile Play1("Players.txt");
    if (Play1.open(QIODevice::WriteOnly | QIODevice::Text)){

        QTextStream data(&Play1);
            data << username1;
            data<<"\n";
            data << pass1;
            data<<"\n";
            data<<score1;
            data<<"\n";

            data << username2;
            data<<"\n";
            data << pass2;
            data<<"\n";
            data<<score2;
            data<<"\n";
            data <<newround<<"\n\n";
}
    }

    QMessageBox msgBox;
//    QMessageBox::StandardButton reply;
            msgBox.setStyleSheet("background : rgb(185, 154, 247)");
            msgBox.setText("Do You Want To Know The Correct Answer?");
            msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
           int reply1 = msgBox.exec();
            if (reply1 == QMessageBox::Yes) {
                auto msgBox2 = new QMessageBox();
                msgBox2->setMinimumSize(300, 300);
                msgBox2->setStyleSheet("QMessageBox{background: rgb(185, 154, 247)}"
                                       "QPushButton{ background : rgb(185, 154, 247)}");
                msgBox2->setText("Coming soon!");
                msgBox2->exec();
            }
            M_Player = new QMediaPlayer();
            audioOutput = new QAudioOutput();
            M_Player -> setAudioOutput(audioOutput);
            M_Player -> setSource(QUrl("qrc:/sound/sounds/Download_Time_out_sound_effect_Royalty_Free_Music_&_Sound_Effects.mp4"));
            audioOutput->setVolume(0.5);
            M_Player -> play();
            hide();
            cho2 = new Choose2(this);
            cho2 -> show();
}

void Choose1::on_ch4_clicked()
{

    QString username1;
    QString username2;
    QString pass1;
    QString pass2;
    int score1;
    int score2;
    int round;
    int newround;

    QFile Play("Players.txt");
    if (Play.open(QIODevice::ReadWrite | QIODevice::Text)){

            QTextStream data(&Play);
            data>>username1;
            data>>pass1;
            data>>score1;
            data>>username2;
            data>>pass2;
            data>>score2;
            data >> round;
            newround=round+1;
                score1++;


    QFile Play1("Players.txt");
    if (Play1.open(QIODevice::WriteOnly | QIODevice::Text)){

        QTextStream data(&Play1);
            data << username1;
            data<<"\n";
            data << pass1;
            data<<"\n";
            data<<score1;
            data<<"\n";

            data << username2;
            data<<"\n";
            data << pass2;
            data<<"\n";
            data<<score2;
            data<<"\n";
            data <<newround<<"\n\n";
}
    }

    QMessageBox msgBox;
//    QMessageBox::StandardButton reply;
            msgBox.setStyleSheet("background : rgb(185, 154, 247)");
            msgBox.setText("Do You Want To Know The Correct Answer?");
            msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
           int reply1 = msgBox.exec();
            if (reply1 == QMessageBox::Yes) {
                auto msgBox2 = new QMessageBox();
                msgBox2->setMinimumSize(300, 300);
                msgBox2->setStyleSheet("QMessageBox{background: rgb(185, 154, 247)}"
                                       "QPushButton{ background : rgb(185, 154, 247)}");
                msgBox2->setText("Coming soon!");
                msgBox2->exec();
            }
            M_Player = new QMediaPlayer();
            audioOutput = new QAudioOutput();
            M_Player -> setAudioOutput(audioOutput);
            M_Player -> setSource(QUrl("qrc:/sound/sounds/Download_Time_out_sound_effect_Royalty_Free_Music_&_Sound_Effects.mp4"));
             audioOutput->setVolume(0.5);
            M_Player -> play();
            hide();
            cho2 = new Choose2(this);
            cho2 -> show();
}
