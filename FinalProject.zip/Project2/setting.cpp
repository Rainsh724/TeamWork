#include "setting.h"
#include "ui_setting.h"
#include "mainwindow.h"
MainWindow *mw2;

setting::setting(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::setting)
{
    ui->setupUi(this);

}

setting::~setting()
{
    delete ui;
}


void setting::on_back_clicked()
{
    M_Player = new QMediaPlayer();
    M_Player -> setMedia(QUrl("qrc:/sound/sounds/ui-digital-button-click-gfx-sounds-1-00-00.mp3"));
    M_Player ->setVolume(50);
    M_Player -> play();
    hide();
    mw2 = new MainWindow(this);
    mw2 -> show();
}
