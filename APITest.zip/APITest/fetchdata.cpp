#include "fetchdata.h"
#include "ui_fetchdata.h"

fetchdata::fetchdata(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::fetchdata)
{
    ui->setupUi(this);
}

fetchdata::~fetchdata()
{
    delete ui;
}

