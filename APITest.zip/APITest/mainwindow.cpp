#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    MainWindow::fetchQuestions();

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::fetchQuestions()
{
    QNetworkAccessManager *manager =  new QNetworkAccessManager(this);
    connect(manager , &QNetworkAccessManager::finished , this , &MainWindow::handleResponse);
    QUrl url("https://opentdb.com/api.php?amount=10&type=multiple");
    QNetworkRequest request(url);
    manager->get(request);
}


void MainWindow::handleResponse(QNetworkReply *reply)
{
    if (reply->error() == QNetworkReply::NoError)
    {
        QByteArray data = reply->readAll();
        QJsonDocument doc = QJsonDocument::fromJson(data);

        if (doc.isObject())
        {
            QJsonObject obj = doc.object();

            if (obj.contains("results") && obj["results"].isArray())
            {
                QJsonArray results = obj["results"].toArray();

                QStringList questionsList;
                QStringList correctAnswersList;
                QList<QStringList> incorrectAnswersList;
                for (const QJsonValue &result : results)
                {
                    QJsonObject questionObj = result.toObject();
                    QString question = questionObj["question"].toString();
                    questionsList.append(question);

                    QString correctAnswer = questionObj["correct_answer"].toString();
                    correctAnswersList.append(correctAnswer);

                    QJsonArray incorrectAnswersArray = questionObj["incorrect_answers"].toArray();
                    QStringList incorrectAnswers;
                    for (const QJsonValue &incorrectAnswer : incorrectAnswersArray)
                    {
                        incorrectAnswers.append(incorrectAnswer.toString());
                    }
                    incorrectAnswersList.append(incorrectAnswers);
                }

                // Display all questions in the label, or handle them as needed
                ui->label->setText(questionsList[0]);
                ui->label_2->setText(correctAnswersList[0]);
                if (incorrectAnswersList.size() > 0 && incorrectAnswersList[0].size() >= 3)
                {
                    ui->label_3->setText(incorrectAnswersList[0][0]);
                    ui->label_4->setText(incorrectAnswersList[0][1]);
                    ui->label_5->setText(incorrectAnswersList[0][2]);
                 }
                }
                else
            {
                ui->label->setText("Error: JSON does not contain 'results' array.");
            }
        }
        else
        {
            ui->label->setText("Error: JSON is not an object.");
        }
    }
    else
    {
        ui->label->setText(tr("Error: ") + reply->errorString());
    }

    reply->deleteLater();
}
