#ifndef FETCHDATA_H
#define FETCHDATA_H

#include "mainwindow.h"
#include <QWidget>
#include <QMainWindow>
#include <QPushButton>
#include <QVBoxLayout>

namespace Ui {
class fetchdata;
}

class fetchdata : public QWidget
{
    Q_OBJECT

public:
    explicit fetchdata(QWidget *parent = nullptr);
    ~fetchdata();

private slots:
    void startButtonClicked();

private:
    Ui::fetchdata *ui;
    MainWindow *m;
};

#endif // FETCHDATA_H
